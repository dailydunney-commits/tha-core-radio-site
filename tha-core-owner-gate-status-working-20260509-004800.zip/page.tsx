﻿"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import OwnerSmartDjCommand from "@/components/owner-smartdj-command";
import GlobalBleepGateButton from "@/components/global-bleep-gate-button";
import GlobalBleepJobsPanel from "@/components/global-bleep-jobs-panel";
import GlobalGateMiniStatus from "@/components/global-gate-mini-status";

type BroadcastState = "off" | "cue" | "live" | "paused";
type PadMode = "JINGLES" | "DROPS" | "COM" | "ADS" | "SMARTDJ" | "AUTODJ" | "LIVEDJ";
type DjMode = "AUTODJ" | "SMARTDJ" | "LIVEDJ";
type PadColor = "yellow" | "red" | "green" | "blue" | "purple" | "orange";

type Pad = {
  label: string;
  mode: PadMode;
  message: string;
  color: PadColor;
};

type LogItem = {
  id: number;
  time: string;
  message: string;
};

type FooterTool = {
  label: string;
  href: string;
  note: string;
  color: PadColor;
};

const STREAM_URL =
  process.env.NEXT_PUBLIC_STREAM_URL ||
  "http://thacoreonlinerad.com/listen/tha-core-online/radio.mp3";

const padModes: PadMode[] = [
  "JINGLES",
  "DROPS",
  "COM",
  "ADS",
  "SMARTDJ",
  "AUTODJ",
  "LIVEDJ",
];

const pads: Pad[] = [
  { label: "Station ID", mode: "JINGLES", message: "Tha Core official station ID fired.", color: "yellow" },
  { label: "Big Intro", mode: "JINGLES", message: "Big intro jingle fired.", color: "orange" },
  { label: "You Locked In", mode: "JINGLES", message: "You are locked in to Tha Core Online Radio.", color: "green" },
  { label: "Morning Vibe", mode: "JINGLES", message: "Morning vibe jingle fired.", color: "yellow" },
  { label: "Late Night", mode: "JINGLES", message: "Late night jingle fired.", color: "purple" },
  { label: "Dancehall Core", mode: "JINGLES", message: "Dancehall Core jingle fired.", color: "red" },
  { label: "Reggae Core", mode: "JINGLES", message: "Reggae Core jingle fired.", color: "green" },
  { label: "Weekend Mix", mode: "JINGLES", message: "Weekend mix jingle fired.", color: "blue" },
  { label: "Fresh Music", mode: "JINGLES", message: "Fresh music jingle fired.", color: "orange" },
  { label: "Back To Back", mode: "JINGLES", message: "Back-to-back music jingle fired.", color: "yellow" },

  { label: "DJ Drop", mode: "DROPS", message: "DJ Daily Bread drop fired.", color: "purple" },
  { label: "Pull Up", mode: "DROPS", message: "Pull up selector drop fired.", color: "red" },
  { label: "Crowd Hype", mode: "DROPS", message: "Crowd hype drop fired.", color: "orange" },
  { label: "Dancehall Drop", mode: "DROPS", message: "Dancehall drop fired.", color: "green" },
  { label: "Hip Hop Drop", mode: "DROPS", message: "Hip hop drop fired.", color: "blue" },
  { label: "Reggae Drop", mode: "DROPS", message: "Reggae drop fired.", color: "yellow" },

  { label: "Com Break", mode: "COM", message: "Commercial break selected.", color: "blue" },
  { label: "Back Soon", mode: "COM", message: "Back soon commercial bridge selected.", color: "yellow" },
  { label: "Sponsor Block", mode: "COM", message: "Sponsor block selected.", color: "green" },
  { label: "Voice Promo", mode: "COM", message: "Voice promo selected.", color: "purple" },
  { label: "Street Promo", mode: "COM", message: "Street promo commercial selected.", color: "orange" },
  { label: "Radio Promo", mode: "COM", message: "Radio promo commercial selected.", color: "red" },

  { label: "Store Ad", mode: "ADS", message: "Tha Core store ad fired.", color: "green" },
  { label: "Print Ad", mode: "ADS", message: "Graphics and printing ad fired.", color: "blue" },
  { label: "Music Promo", mode: "ADS", message: "Music promotion ad fired.", color: "orange" },
  { label: "Sponsor Ad", mode: "ADS", message: "Sponsor ad fired.", color: "yellow" },

  { label: "Smart Mix", mode: "SMARTDJ", message: "SmartDJ mix selected.", color: "purple" },
  { label: "Smart Jingle", mode: "SMARTDJ", message: "SmartDJ jingle timing selected.", color: "yellow" },
  { label: "Smart Ads", mode: "SMARTDJ", message: "SmartDJ ad timing selected.", color: "green" },
  { label: "Smart Talk", mode: "SMARTDJ", message: "SmartDJ talk break selected.", color: "blue" },

  { label: "AutoDJ Flow", mode: "AUTODJ", message: "AutoDJ flow selected.", color: "orange" },
  { label: "Auto Next", mode: "AUTODJ", message: "AutoDJ next command selected.", color: "green" },
  { label: "Auto Break", mode: "AUTODJ", message: "AutoDJ break selected.", color: "blue" },
  { label: "Auto Rotate", mode: "AUTODJ", message: "AutoDJ rotation selected.", color: "yellow" },

  { label: "Live Mic", mode: "LIVEDJ", message: "Live DJ mic armed.", color: "red" },
  { label: "Talk Break", mode: "LIVEDJ", message: "Live DJ talk break selected.", color: "yellow" },
  { label: "Shout Out", mode: "LIVEDJ", message: "Live shout out selected.", color: "orange" },
  { label: "Request Line", mode: "LIVEDJ", message: "Request line opened.", color: "green" },
];

const footerTools: FooterTool[] = [
  { label: "Blog", href: "/blog", note: "Blog page shortcut ready", color: "yellow" },
  { label: "News", href: "/news", note: "News desk shortcut ready", color: "red" },
  { label: "Weather", href: "/weather", note: "Weather reader shortcut ready", color: "blue" },
  { label: "Time Reader", href: "/time", note: "Time reader shortcut ready", color: "purple" },
  { label: "Cash Pot", href: "/cashpot", note: "Cash Pot / lotto shortcut ready", color: "green" },
  { label: "Store", href: "/store", note: "Store shortcut ready", color: "green" },
  { label: "Community Chat", href: "/chat", note: "Community and chat shortcut ready", color: "orange" },
  { label: "Upload", href: "/upload", note: "Upload center shortcut ready", color: "yellow" },
  { label: "Requests", href: "/requests", note: "Song request shortcut ready", color: "green" },
  { label: "Schedule", href: "/schedule", note: "Show schedule shortcut ready", color: "blue" },
  { label: "Promos", href: "/promos", note: "Promo tools shortcut ready", color: "red" },
];


type SmartDjControlPlaylistTrack = {
  id: string;
  title: string;
  artist?: string;
  source?: string;
  reason?: string;
  audioUrl?: string;
  url?: string;
  streamUrl?: string; isExplicit?: boolean; explicitWords?: string[]; };

function SmartDjControlPlaylist() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [tracks, setTracks] = useState<SmartDjControlPlaylistTrack[]>([]);
  const [playingId, setPlayingId] = useState("");
  const [status, setStatus] = useState("SmartDJ control playlist ready.");
  const [bleepStatusById, setBleepStatusById] = useState<Record<string, string>>({});
  const [queueStatusById, setQueueStatusById] = useState<Record<string, string>>({});

  useEffect(() => {
    loadSmartDjPlaylist();

    const timer = window.setInterval(() => {
      loadSmartDjPlaylist();
    }, 2500);

    return () => window.clearInterval(timer);
  }, []);

  function normalizeSmartDjTracks(payload: any): SmartDjControlPlaylistTrack[] {
    const rawList = Array.isArray(payload?.playlist)
      ? payload.playlist
      : Array.isArray(payload?.lastPlaylist)
        ? payload.lastPlaylist
        : Array.isArray(payload?.tracks)
          ? payload.tracks
          : Array.isArray(payload?.lastResult?.playlist)
            ? payload.lastResult.playlist
            : Array.isArray(payload?.result?.playlist)
              ? payload.result.playlist
              : [];

    return rawList.map((track: any, index: number) => ({
      id: String(track?.id ?? `smartdj-control-track-${index + 1}`),
      title: String(track?.title ?? track?.name ?? `SmartDJ Track ${index + 1}`),
      artist: String(track?.artist ?? track?.creator ?? "SmartDJ"),
      source: String(track?.source ?? "Tha Core SmartDJ"),
      reason: String(track?.reason ?? "Created by SmartDJ."),
      audioUrl: String(track?.audioUrl ?? track?.streamUrl ?? track?.url ?? ""),
      streamUrl: String(track?.streamUrl ?? ""),
      url: String(track?.url ?? ""),
    }));
  }

  function getTrackAudioUrl(track: SmartDjControlPlaylistTrack) {
    return track.audioUrl || track.streamUrl || track.url || "";
  }

  async function loadSmartDjPlaylist() {
    try {
      const response = await fetch("/api/smartdj/command", {
        method: "GET",
        cache: "no-store",
      });

      const data = await response.json();
      const nextTracks = normalizeSmartDjTracks(data);

      setTracks(nextTracks);

      if (nextTracks.length > 0) {
        setStatus(`SmartDJ playlist loaded on control panel: ${nextTracks.length} track(s).`);
      } else {
        setStatus("No SmartDJ playlist created yet. Ask SmartDJ to build one.");
      }
    } catch {
      setStatus("Could not load SmartDJ playlist from command engine.");
    }
  }

  async function playSmartDjTrack(track: SmartDjControlPlaylistTrack) {
    try {
      setBleepStatusById((current) => ({
        ...current,
        [track.id]: "Running global bleep check before preview...",
      }));

      const bleepResponse = await fetch("/api/radio/bleep-check", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          source: "CONTROL_PANEL",
          mode: "preview",
          requireClean: true,
          track,
        }),
      });

      const bleepData = await bleepResponse.json();
      const bleepMessage = bleepData?.message || "Global bleep check finished.";

      setBleepStatusById((current) => ({
        ...current,
        [track.id]: bleepMessage,
      }));

      if (bleepData?.needsBleep) {
        setPlayingId("");
        setStatus(bleepMessage);
        return;
      }

      const audioUrl = getTrackAudioUrl(track);
      setPlayingId(track.id);

      if (!audioUrl) {
        setStatus(
          `Loaded on control panel: ${track.artist ?? "SmartDJ"} - ${track.title}. No real audio URL attached yet.`
        );
        return;
      }

      const player = audioRef.current;

      if (!player) {
        setStatus("SmartDJ playlist player is not ready.");
        return;
      }

      player.pause();
      player.src = audioUrl;
      player.load();
      await player.play();

      setStatus(`Previewing clean/radio-safe track: ${track.artist ?? "SmartDJ"} - ${track.title}`);
    } catch {
      setPlayingId("");
      setStatus("Global bleep check failed. Preview blocked.");
    }
  }

  
  
  async function checkSmartDjTrackForBleep(track: SmartDjControlPlaylistTrack) {
    try {
      setBleepStatusById((current) => ({
        ...current,
        [track.id]: "Checking track for explicit words...",
      }));

      const response = await fetch("/api/radio/bleep-check", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({ track }),
      });

      const data = await response.json();

      const nextStatus = data?.message || "Bleep check finished.";

      setBleepStatusById((current) => ({
        ...current,
        [track.id]: nextStatus,
      }));

      setStatus(nextStatus);
    } catch {
      setBleepStatusById((current) => ({
        ...current,
        [track.id]: "Bleep check failed. Hold before broadcast.",
      }));

      setStatus("Bleep check failed. Hold before broadcast.");
    }
  }

  
  async function runGlobalSafeActionGate(payload: {
    source: string;
    action: string;
    track?: any;
    text?: string;
    requireClean?: boolean;
  }) {
    try {
      const response = await fetch("/api/radio/safe-action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          source: payload.source,
          action: payload.action,
          mode: "pre_broadcast",
          requireClean: payload.requireClean !== false,
          track: payload.track,
          text: payload.text,
        }),
      });

      const data = await response.json();

      if (!data?.allowed) {
        const message =
          data?.message ||
          "BLEEP JOB CREATED - clean/bleeped copy required before broadcast.";

        setScreenTitle("GLOBAL BLEEP HOLD");
        setScreenText(message);
        addLog(message);

        return {
          allowed: false,
          message,
          data,
        };
      }

      const message =
        data?.message || "Passed global radio bleep check. Action allowed.";

      addLog(message);

      return {
        allowed: true,
        message,
        data,
      };
    } catch {
      const message = "Global bleep gate failed. Action held before broadcast.";

      setScreenTitle("GLOBAL BLEEP ERROR");
      setScreenText(message);
      addLog(message);

      return {
        allowed: false,
        message,
        data: null,
      };
    }
  }

  async function sendSmartDjTrackToQueue(track: SmartDjControlPlaylistTrack) {
    try {
      const checkingStatus = "SmartDJ running Global Bleep Gate before queue...";

      setQueueStatusById((current) => ({
        ...current,
        [track.id]: checkingStatus,
      }));

      setBleepStatusById((current) => ({
        ...current,
        [track.id]: checkingStatus,
      }));

      const safeResponse = await fetch("/api/radio/safe-action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          source: "SMARTDJ",
          action: "smartdj_send_to_queue",
          mode: "pre_broadcast",
          requireClean: true,
          track,
          text: `${track.artist ?? "SmartDJ"} ${track.title ?? ""} ${track.source ?? ""}`,
        }),
      });

      const safeData = await safeResponse.json();

      const safeMessage =
        safeData?.message ||
        "Global Bleep Gate check finished.";

      setBleepStatusById((current) => ({
        ...current,
        [track.id]: safeMessage,
      }));

      if (!safeData?.allowed) {
        const holdStatus =
          safeMessage ||
          "BLEEP JOB CREATED - clean/bleeped copy required before SmartDJ queue.";

        setQueueStatusById((current) => ({
          ...current,
          [track.id]: holdStatus,
        }));

        setStatus(holdStatus);
        return;
      }

      const response = await fetch("/api/smartdj/queue", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          track: {
            ...track,
            isExplicit: false,
            explicitWords: [],
          },
        }),
      });

      const data = await response.json();

      const queueMessage =
        data?.item?.queueStatus ||
        data?.message ||
        "Track sent to SmartDJ queue.";

      const finalStatus = `Passed Global Bleep Gate. ${queueMessage}`;

      setQueueStatusById((current) => ({
        ...current,
        [track.id]: finalStatus,
      }));

      setStatus(finalStatus);
    } catch {
      const failStatus =
        "SmartDJ queue blocked. Global Bleep Gate failed before queue.";

      setQueueStatusById((current) => ({
        ...current,
        [track.id]: failStatus,
      }));

      setBleepStatusById((current) => ({
        ...current,
        [track.id]: failStatus,
      }));

      setStatus(failStatus);
    }
  }
  function stopSmartDjTrack() {
    const player = audioRef.current;

    if (player) {
      player.pause();
      player.currentTime = 0;
    }

    setPlayingId("");
    setStatus("SmartDJ control playlist stopped.");
  }

  return (
    <section className="owner-control-smartdj-playlist panel">
      <audio ref={audioRef} preload="none" />

      <div className="owner-control-smartdj-playlist-head">
        <div>
          <strong>SMARTDJ CREATED PLAYLIST</strong>
          <span>Playlist created by SmartDJ will show here and play from control panel.</span>
        </div>

        <div className="owner-control-smartdj-playlist-actions">
          <button type="button" onClick={loadSmartDjPlaylist}>
            REFRESH
          </button>
          <button type="button" onClick={stopSmartDjTrack}>
            STOP
          </button>
        </div>
      </div>

      {tracks.length > 0 ? (
        <div className="owner-control-smartdj-playlist-list">
          {tracks.map((track, index) => {
            const isPlaying = playingId === track.id;

            return (
              <div
                key={`${track.id}-${index}`}
                className={`owner-control-smartdj-playlist-row ${
                  isPlaying ? "is-playing" : ""
                }`}
              >
                <div className="owner-control-smartdj-playlist-info">
                  <b>
                    {index + 1}. {track.artist ?? "SmartDJ"} - {track.title}
                  </b>
                  <small>{track.source ?? "Tha Core SmartDJ"}</small>
                </div>

                <div className="owner-control-smartdj-row-actions">
                  <button type="button" onClick={() => playSmartDjTrack(track)}>
                    {isPlaying ? "PREVIEWING" : "PREVIEW"}
                  </button>

                  <button type="button" onClick={() => checkSmartDjTrackForBleep(track)}>
                    BLEEP CHECK
                  </button>

                  <button type="button" onClick={() => sendSmartDjTrackToQueue(track)}>
                    SEND TO QUEUE
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="owner-control-smartdj-empty">
          No playlist yet. Type a SmartDJ command below and press ASK SMARTDJ.
        </p>
      )}

      <p className="owner-control-smartdj-player-status">{status}</p>
    </section>
  );
}

export default function OwnerControlPanelPage() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const overlayAudioRef = useRef<HTMLAudioElement | null>(null);

  const [broadcast, setBroadcast] = useState<BroadcastState>("off");
  const [selectedMode, setSelectedMode] = useState<PadMode>("JINGLES");
  const [smartDjCommandText, setSmartDjCommandText] = useState("find and play mothers day song");
  const [smartDjCommandResult, setSmartDjCommandResult] = useState("SmartDJ command ready.");

  const SELECTED_DISPLAY_MEMORY_KEY = "tha-core-owner-selected-display-v1";

  useEffect(() => {
    try {
      const savedDisplay = window.localStorage.getItem(SELECTED_DISPLAY_MEMORY_KEY);

      if (
        savedDisplay === "JINGLES" ||
        savedDisplay === "DROPS" ||
        savedDisplay === "COM" ||
        savedDisplay === "ADS" ||
        savedDisplay === "SMARTDJ" ||
        savedDisplay === "AUTODJ" ||
        savedDisplay === "LIVEDJ"
      ) {
        setSelectedMode(savedDisplay);
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(SELECTED_DISPLAY_MEMORY_KEY, selectedMode);
    } catch {
      // ignore storage errors
    }
  }, [selectedMode]);

  const [autoDj, setAutoDj] = useState(true);
  const [smartDj, setSmartDj] = useState(false);
  const [liveDj, setLiveDj] = useState(false);

  const DJ_MODE_MEMORY_KEY = "tha-core-owner-dj-mode-v1";

  useEffect(() => {
    try {
      const savedMode = window.localStorage.getItem(DJ_MODE_MEMORY_KEY);

      if (savedMode === "AUTODJ") {
        setAutoDj(true);
        setSmartDj(false);
        setLiveDj(false);
        setSelectedMode("AUTODJ");
      }

      if (savedMode === "SMARTDJ") {
        setAutoDj(false);
        setSmartDj(true);
        setLiveDj(false);
        setSelectedMode("SMARTDJ");
      }

      if (savedMode === "LIVEDJ") {
        setAutoDj(false);
        setSmartDj(false);
        setLiveDj(true);
        setSelectedMode("LIVEDJ");
      }
    } catch {
      // Ignore browser storage errors.
    }
  }, []);

  useEffect(() => {
    try {
      const currentMode = smartDj ? "SMARTDJ" : liveDj ? "LIVEDJ" : "AUTODJ";
      window.localStorage.setItem(DJ_MODE_MEMORY_KEY, currentMode);
    } catch {
      // Ignore browser storage errors.
    }
  }, [autoDj, smartDj, liveDj]);
  const [micLive, setMicLive] = useState(false);
  const [monitorOn, setMonitorOn] = useState(true);

  const [screenTitle, setScreenTitle] = useState("STUDIO READY");
  const [screenText, setScreenText] = useState(
    "Control panel ready. Now Playing auto-updates. Jingles, drops, commercials, and ads are wired to the broadcast pad bridge."
  );

  const [nowPlayingText, setNowPlayingText] = useState("Loading current song...");
  const [listenerText, setListenerText] = useState("Checking listeners...");
  const [stationText, setStationText] = useState("Tha Core Online Radio");
  const [lastUpdatedText, setLastUpdatedText] = useState("Auto refresh active");

  const [volume, setVolume] = useState(72);
  const [monitorVol, setMonitorVol] = useState(65);
  const [micGain, setMicGain] = useState(45);
  const [musicGain, setMusicGain] = useState(70);
  const [tempo, setTempo] = useState(50);
  const [bass, setBass] = useState(64);
  const [mid, setMid] = useState(58);
  const [high, setHigh] = useState(61);
  const [reverb, setReverb] = useState(20);
  const [delay, setDelay] = useState(12);
  const [echo, setEcho] = useState(18);
  const [crossfade, setCrossfade] = useState(50);
  const [deckAGain, setDeckAGain] = useState(72);
  const [deckBGain, setDeckBGain] = useState(72);
  const [adBed, setAdBed] = useState(38);
  const [jingleBed, setJingleBed] = useState(48);

  const [logs, setLogs] = useState<LogItem[]>([
    {
      id: 1,
      time: "Now",
      message: "Latest studio panel loaded with auto now-playing and filled deck controls.",
    },
  ]);

  const isLive = broadcast === "live";
  const isCue = broadcast === "cue";
  const visiblePads = pads.filter((pad) => pad.mode === selectedMode);
  const currentDjMode: DjMode = smartDj ? "SMARTDJ" : liveDj ? "LIVEDJ" : "AUTODJ";

  const broadcastLabel = useMemo(() => {
    if (broadcast === "live" && liveDj) return "LIVE DJ ON AIR";
    if (broadcast === "live" && smartDj) return "SMARTDJ BROADCASTING";
    if (broadcast === "live" && autoDj) return "AUTODJ BROADCASTING";
    if (broadcast === "live") return "BROADCAST LIVE";
    if (broadcast === "paused") return "BROADCAST PAUSED";
    if (broadcast === "cue") return "BROADCAST CUED";
    return "OFF AIR";
  }, [broadcast, liveDj, smartDj, autoDj]);

  function stamp() {
    return new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function addLog(message: string) {
    setLogs((current) => [
      { id: Date.now() + Math.floor(Math.random() * 1000000), time: stamp(), message },
      ...current.slice(0, 5),
    ]);
  }

  function getPadSlug(label: string) {
    return label
      .toLowerCase()
      .replace(/&/g, "and")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function getPad(label: string) {
    return pads.find((pad) => pad.label === label) || pads[0];
  }

  function setMainVolume(value: number) {
    setVolume(value);

    if (audioRef.current) {
      audioRef.current.volume = value / 100;
    }
  }

  function setDjMode(mode: DjMode) {
    const nextAutoDj = mode === "AUTODJ";
    const nextSmartDj = mode === "SMARTDJ";
    const nextLiveDj = mode === "LIVEDJ";

    setAutoDj(nextAutoDj);
    setSmartDj(nextSmartDj);
    setLiveDj(nextLiveDj);
    setMicLive(nextLiveDj);
    setSelectedMode(mode);

    setScreenTitle(`${mode} ACTIVE`);

    if (mode === "AUTODJ") {
      setScreenText("AutoDJ is active. Playlist flow and automatic rotation are selected.");
      addLog("All-in-one smart switch changed to AutoDJ.");
    }

    if (mode === "SMARTDJ") {
      setScreenText("SmartDJ is active. Smart jingles, drops, ads, and talk timing are selected.");
      addLog("All-in-one smart switch changed to SmartDJ.");
    }

    if (mode === "LIVEDJ") {
      setScreenText("LiveDJ is active. Manual DJ control and mic channel are armed.");
      addLog("All-in-one smart switch changed to LiveDJ.");
    }
  }

  async function callRadioAction(action: "skip" | "restart" | "start" | "stop") {
    setScreenTitle(`${action.toUpperCase()} SENT`);
    setScreenText(`Sending ${action} command to radio backend...`);
    addLog(`${action.toUpperCase()} command sending.`);

    try {
      const response = await fetch("/api/radio/action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ action }),
      });

      const data = await response.json();

      if (!response.ok || !data?.ok) {
        setScreenTitle(`${action.toUpperCase()} FAILED`);
        setScreenText(data?.error || `Could not complete ${action}. Check AzuraCast settings.`);
        addLog(`${action.toUpperCase()} failed.`);
        return;
      }

      setScreenTitle(`${action.toUpperCase()} COMPLETE`);
      setScreenText(data?.message || `${action} command completed.`);
      addLog(`${action.toUpperCase()} completed.`);
      refreshNowPlaying();
    } catch {
      setScreenTitle(`${action.toUpperCase()} ERROR`);
      setScreenText("Could not reach the radio action API route.");
      addLog(`${action.toUpperCase()} API error.`);
    }
  }

  async function sendPadToBroadcast(pad: Pad) {
    const slug = getPadSlug(pad.label);

    setScreenTitle(`${pad.mode} SENDING`);
    setScreenText(`Sending ${pad.label} to AzuraCast broadcast queue...`);
    addLog(`Sending ${pad.label} to broadcast.`);

    try {
      const response = await fetch("/api/radio/pad", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ slug }),
      });

      const data = await response.json();

      if (!response.ok || !data?.ok) {
        setScreenTitle(`${pad.mode} NOT LIVE YET`);
        setScreenText(data?.error || `${pad.label} is not mapped to AzuraCast yet.`);
        addLog(`${pad.label} needs AzuraCast request mapping.`);
        return;
      }

      setScreenTitle(`${pad.mode} LIVE SENT`);
      setScreenText(data?.message || `${pad.label} sent to AzuraCast.`);
      addLog(`${pad.label} sent to AzuraCast broadcast.`);
      refreshNowPlaying();
    } catch {
      setScreenTitle(`${pad.mode} ERROR`);
      setScreenText("Could not reach the pad broadcast API route.");
      addLog(`${pad.label} broadcast API error.`);
    }
  }

  async function refreshNowPlaying() {
    try {
      const response = await fetch("/api/radio/now-playing", {
        cache: "no-store",
      });

      const data = await response.json();

      if (!response.ok || !data?.ok) {
        setNowPlayingText("Now-playing failed to load.");
        setListenerText("Check API route.");
        setLastUpdatedText(`Failed ${stamp()}`);
        addLog("Auto now-playing refresh failed.");
        return;
      }

      const text = data?.nowPlaying?.text || "Unknown song";
      const listeners = data?.listeners?.current ?? 0;
      const unique = data?.listeners?.unique ?? 0;
      const station = data?.station?.name || "Tha Core Online Radio";

      setNowPlayingText(text);
      setListenerText(`${listeners} current • ${unique} unique`);
      setStationText(station);
      setLastUpdatedText(`Updated ${stamp()}`);
    } catch {
      setNowPlayingText("Could not reach now-playing API.");
      setListenerText("API error.");
      setLastUpdatedText(`Error ${stamp()}`);
      addLog("Now-playing API error.");
    }
  }

  useEffect(() => {
    refreshNowPlaying();

    const timer = window.setInterval(() => {
      refreshNowPlaying();
    }, 20000);

    return () => window.clearInterval(timer);
  }, []);

  function cueBroadcast() {
    setBroadcast("cue");
    setScreenTitle("BROADCAST CUED");
    setScreenText("Broadcast is cued. Turntables slow spin. Hit main Play / Pause to start the full broadcast monitor.");
    addLog("Broadcast cued.");
  }

  async function playPauseBroadcast() {
    const audio = audioRef.current;

    if (!audio) return;

    if (broadcast === "live") {
      audio.pause();
      setBroadcast("paused");
      setScreenTitle("BROADCAST PAUSED");
      setScreenText("Main Play / Pause paused the full broadcast monitor. Press it again to continue.");
      addLog("Main Play / Pause paused the full broadcast monitor.");
      return;
    }

    try {
      audio.volume = volume / 100;
      audio.muted = !monitorOn;

      await audio.play();

      setBroadcast("live");
      setScreenTitle("BROADCAST LIVE");
      setScreenText("Main Play / Pause started the full broadcast monitor. Both turntables are spinning live.");
      addLog("Main Play / Pause started the broadcast. Turntables spinning.");
    } catch {
      setScreenTitle("PLAYBACK BLOCKED");
      setScreenText("Browser blocked the stream. Click Play / Pause again or check stream URL / HTTPS.");
      addLog("Playback blocked.");
    }
  }

  function stopBroadcast() {
    const audio = audioRef.current;

    if (audio) {
      audio.pause();

      try {
        audio.currentTime = 0;
      } catch {
        // Live stream reset may not be allowed.
      }
    }

    setBroadcast("off");
    setMicLive(false);
    setScreenTitle("STOP ALL");
    setScreenText("Stop All stopped the full control room broadcast monitor.");
    addLog("Stop All pressed.");
  }

  function skipNext() {
    callRadioAction("skip");
  }

  function studioSkip() {
    setScreenTitle("STUDIO SKIP");
    setScreenText("Studio Skip pressed. Ready for clean SmartDJ / AutoDJ transition.");
    addLog("Studio Skip pressed.");
  }

  function toggleMonitor() {
    setMonitorOn((current) => {
      const next = !current;

      if (audioRef.current) {
        audioRef.current.muted = !next;
      }

      setScreenTitle(next ? "MONITOR ON" : "MONITOR MUTED");
      setScreenText(
        next
          ? "In-house studio monitor is on."
          : "In-house monitor is muted. Public stream is not affected."
      );
      addLog(next ? "Monitor turned on." : "Monitor muted.");

      return next;
    });
  }

  function effectPunch(type: "reverb" | "delay" | "echo" | "bass" | "ad" | "jingle") {
    if (type === "reverb") setReverb((value) => Math.min(value + 12, 100));
    if (type === "delay") setDelay((value) => Math.min(value + 12, 100));
    if (type === "echo") setEcho((value) => Math.min(value + 12, 100));
    if (type === "bass") setBass((value) => Math.min(value + 10, 100));
    if (type === "ad") setAdBed((value) => Math.min(value + 10, 100));
    if (type === "jingle") setJingleBed((value) => Math.min(value + 10, 100));

    setScreenTitle("EFFECT ADJUSTED");
    setScreenText(`${type.toUpperCase()} control adjusted from the main broadcast section.`);
    addLog(`${type.toUpperCase()} adjusted.`);
  }

  async function firePad(pad: Pad) {
    const gate = await runGlobalSafeActionGate({
      source: pad.mode || "CONTROL_PANEL",
      action: "fire_pad",
      requireClean: true,
      track: {
        id: pad.label,
        title: pad.label,
        artist: pad.mode,
        source: "Owner Control Panel Pad",
        reason: pad.message,
      },
      text: `${pad.mode} ${pad.label} ${pad.message}`,
    });

    if (!gate.allowed) {
      return;
    }

    if (audioRef.current) {
      const next = !audioRef.current.paused;

      if (next) {
        audioRef.current.pause();
      }
    }

    setSelectedMode(pad.mode);
    setScreenTitle(`${pad.mode}: ${pad.label}`);
    setScreenText(pad.message);

    if (pad.mode === "SMARTDJ") setDjMode("SMARTDJ");
    if (pad.mode === "AUTODJ") setDjMode("AUTODJ");
    if (pad.mode === "LIVEDJ") setDjMode("LIVEDJ");

    sendPadToBroadcast(pad);
    addLog(`${pad.mode}: ${pad.label}`);
  }

  function selectDisplay(mode: PadMode, label: string) {
    setSelectedMode(mode);
    setScreenTitle(`${label.toUpperCase()} DISPLAY`);
    setScreenText(`${label} display buttons are now loaded in the hero page.`);
    addLog(`${label} display selected.`);
  }

  function selectTool(tool: FooterTool) {
    setScreenTitle(`${tool.label.toUpperCase()} DOCK`);
    setScreenText(tool.note);
    addLog(`${tool.label} footer dock selected.`);
  }

  const deckAQuickPads = [
    getPad("Station ID"),
    getPad("Big Intro"),
    getPad("DJ Drop"),
    getPad("Com Break"),
    getPad("Store Ad"),
    getPad("Sponsor Ad"),
  ];

  const deckBQuickPads = [
    getPad("Back To Back"),
    getPad("Pull Up"),
    getPad("Radio Promo"),
    getPad("Music Promo"),
    getPad("Smart Jingle"),
    getPad("Auto Next"),
  ];

  return (
    <main className="control-page">
      <audio ref={audioRef} src={STREAM_URL} preload="none" />
      <audio ref={overlayAudioRef} preload="auto" />

      <section className="shell">
        <header className="topbar">
          <div>
            <p className="eyebrow">THA CORE ONLINE RADIO</p>
            <h1>Studio Control Panel</h1>
            <p className="subtitle">
              Jet black and blood red studio layout with live auto-updating now-playing status,
              all-in-one AutoDJ / SmartDJ / LiveDJ switch, filled broadcast controls, deck quick
              pads, jingles, drops, commercials, ads, sliders, and radio API buttons.
            </p>
          </div>

          <div className="brand-badge">
            <span className="crown">♛</span>
            <strong>TC</strong>
            <small>STUDIO LIVE</small>
          </div>
        </header>

        <section className="status-row">
          <StatusCard label="Broadcast" value={broadcastLabel} tone={isLive ? "green" : isCue ? "yellow" : "red"} />
          <StatusCard label="AutoDJ" value={autoDj ? "ACTIVE" : "OFF"} tone={autoDj ? "yellow" : "red"} />
          <StatusCard label="SmartDJ" value={smartDj ? "ACTIVE" : "OFF"} tone={smartDj ? "blue" : "red"} />
          <StatusCard label="LiveDJ" value={liveDj ? "LIVE" : "OFF"} tone={liveDj ? "green" : "red"} />
          <StatusCard label="Mic" value={micLive ? "ARMED" : "MUTED"} tone={micLive ? "purple" : "red"} />
          <StatusCard label="Monitor" value={monitorOn ? "ON" : "MUTED"} tone={monitorOn ? "green" : "red"} />
        </section>

        <GlobalBleepGateButton />
      <GlobalBleepJobsPanel />
      <GlobalGateMiniStatus />

      <section className="central-log">
          <PanelHeading left="Central Control Log" right="Above Studio" />

          <div className="log-row">
            {logs.slice(0, 4).map((log, index) => (
              <div key={`${log.id}-${index}`} className="log-card">
                <span>{log.time}</span>
                <p>{log.message}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="now-playing-bar">
          <div>
            <span>Now Playing</span>
            <strong>{nowPlayingText}</strong>
          </div>

          <div>
            <span>Listeners</span>
            <strong>{listenerText}</strong>
          </div>

          <div>
            <span>Station</span>
            <strong>{stationText}</strong>
          </div>

          <button type="button" onClick={refreshNowPlaying}>
            Refresh • {lastUpdatedText}
          </button>
        </section>

        <section className="main-studio">
          <section className="left-display panel">
            <PanelHeading left={screenTitle} right={broadcastLabel} />

            <div className="screen">
              <p className="screen-kicker">LIVE DISPLAY</p>
              <h2>{broadcastLabel}</h2>
              <p>{screenText}</p>

              <div className="lamp-grid">
                <span className={autoDj ? "lamp on yellow" : "lamp"}>AUTODJ</span>
                <span className={smartDj ? "lamp on blue" : "lamp"}>SMARTDJ</span>
                <span className={liveDj ? "lamp on green" : "lamp"}>LIVEDJ</span>
                <span className={micLive ? "lamp on purple" : "lamp"}>MIC</span>
              </div>
            </div>

            <div className="hero-smart-area">
              <PanelHeading left="All-In-One Smart Switch" right={currentDjMode} />

              <div className="smart-mode-switch">
                <button
                  type="button"
                  onClick={async () => {
                      addLog("AutoDJ gate checking next clean/bleeped track...");

                      try {
                        const response = await fetch("/api/autodj/gated-next", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                          },
                          cache: "no-store",
                          body: JSON.stringify({
                            action: "next",
                          }),
                        });

                        const data = await response.json();

                        if (data?.allowAutoDj && data?.safe) {
                          setDjMode("AUTODJ");
                          addLog(
                            `AutoDJ gate approved: ${
                              data?.track?.artist || "AutoDJ"
                            } - ${data?.track?.title || "clean/bleeped track"}`
                          );
                        } else {
                          addLog(
                            `AutoDJ gate blocked track: ${
                              data?.message ||
                              "Needs clean version or bleeped copy before rotation."
                            }`
                          );
                        }
                      } catch {
                        addLog("AutoDJ gate error. AutoDJ was not switched on.");
                      }
                    }}
                  className={currentDjMode === "AUTODJ" ? "active auto" : "auto"}
                >
                  <span>AutoDJ</span>
                  <b>Playlist</b>
                </button>

                <button
                  type="button"
                  onClick={() => setDjMode("SMARTDJ")}
                  className={currentDjMode === "SMARTDJ" ? "active smart" : "smart"}
                >
                  <span>SmartDJ</span>
                  <b>Smart Flow</b>
                </button>

                <button
                  type="button"
                  onClick={() => setDjMode("LIVEDJ")}
                  className={currentDjMode === "LIVEDJ" ? "active live" : "live"}
                >
                  <span>LiveDJ</span>
                  <b>Mic / Manual</b>
                </button>
              </div>

              <div className="display-switches">
                <button type="button" onClick={() => selectDisplay("JINGLES", "Jingles")} className="display-btn blood">
                  Jingles Display
                </button>

                <button type="button" onClick={() => selectDisplay("COM", "Commercial")} className="display-btn dark">
                  Commercial Display
                </button>
              </div>

              <div className="hero-tabs">
                {padModes.map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => selectDisplay(mode, mode)}
                    className={selectedMode === mode ? "active" : ""}
                  >
                    {mode}
                  </button>
                ))}
              </div>

              <div className="hero-pad-grid">
                {visiblePads.map((pad) => (
                  <button
                    key={`${pad.mode}-${pad.label}`}
                    type="button"
                    onClick={() => firePad(pad)}
                    className={`pad ${pad.color}`}
                  >
                    <small>{pad.mode}</small>
                    <strong>{pad.label}</strong>
                  </button>
                ))}
              </div>
            </div>
          </section>

          <section className="turntable-stage">
            <Turntable
              title="DECK A"
              label="MAIN BROADCAST"
              state={broadcast}
              quickPads={deckAQuickPads}
              onPad={firePad}
              onCue={cueBroadcast}
              onSync={studioSkip}
              onLoad={() => selectDisplay("JINGLES", "Deck A")}
            />

            <section className="broadcast-center">
              <div className="cam-box">
                <PanelHeading left="Studio Cam" right={micLive ? "MIC LIVE" : "READY"} />

                <div className="cam-view">
                  <div className={isLive ? "cam-bars active" : "cam-bars"}>
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                  </div>

                  <p>Camera / video call / live studio window</p>
                </div>
              </div>

              <button type="button" onClick={playPauseBroadcast} className={isLive ? "main-play active" : "main-play"}>
                <span>MAIN BROADCAST</span>
                <b>{isLive ? "PAUSE ALL" : "PLAY ALL"}</b>
              </button>

              <div className="broadcast-buttons">
                <button type="button" onClick={cueBroadcast} className="btn blood">Cue</button>
                <button type="button" onClick={stopBroadcast} className="btn red">Stop All</button>
                <button type="button" onClick={skipNext} className="btn blue">Skip</button>
                <button type="button" onClick={studioSkip} className="btn purple">Studio Skip</button>
                <button type="button" onClick={toggleMonitor} className="btn green">Monitor</button>
                <button
                  type="button"
                  onClick={() => {
                    setMicLive((current) => !current);
                    addLog("Mic toggled.");
                  }}
                  className="btn orange"
                >
                  Mic
                </button>
              </div>

              <div className="center-pad-bank">
                <button type="button" onClick={() => firePad(getPad("Station ID"))}>Station ID</button>
                <button type="button" onClick={() => firePad(getPad("DJ Drop"))}>DJ Drop</button>
                <button type="button" onClick={() => firePad(getPad("Com Break"))}>Com Break</button>
                <button type="button" onClick={() => firePad(getPad("Store Ad"))}>Store Ad</button>
                <button type="button" onClick={() => firePad(getPad("Sponsor Ad"))}>Sponsor Ad</button>
                <button type="button" onClick={() => firePad(getPad("Music Promo"))}>Music Promo</button>
              </div>

              <div className="mode-buttons">
                <button type="button" onClick={() => selectDisplay("JINGLES", "Jingles")}>Jingles</button>
                <button type="button" onClick={() => selectDisplay("DROPS", "Drops")}>Drops</button>
                <button type="button" onClick={() => selectDisplay("COM", "Commercial")}>Com</button>
                <button type="button" onClick={() => selectDisplay("ADS", "Ads")}>Ads</button>
                <button type="button" onClick={() => setDjMode("SMARTDJ")}>SmartDJ</button>
                <button type="button" onClick={async () => {
                      addLog("AutoDJ gate checking next clean/bleeped track...");

                      try {
                        const response = await fetch("/api/autodj/gated-next", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                          },
                          cache: "no-store",
                          body: JSON.stringify({
                            action: "next",
                          }),
                        });

                        const data = await response.json();

                        if (data?.allowAutoDj && data?.safe) {
                          setDjMode("AUTODJ");
                          addLog(
                            `AutoDJ gate approved: ${
                              data?.track?.artist || "AutoDJ"
                            } - ${data?.track?.title || "clean/bleeped track"}`
                          );
                        } else {
                          addLog(
                            `AutoDJ gate blocked track: ${
                              data?.message ||
                              "Needs clean version or bleeped copy before rotation."
                            }`
                          );
                        }
                      } catch {
                        addLog("AutoDJ gate error. AutoDJ was not switched on.");
                      }
                    }}>AutoDJ</button>
                <button type="button" onClick={() => setDjMode("LIVEDJ")}>LiveDJ</button>
                <button type="button" onClick={() => firePad(visiblePads[0] || pads[0])}>Smart Fire</button>
                <button type="button" onClick={refreshNowPlaying}>Now Playing</button>
              </div>

              <div className="effect-buttons">
                <button type="button" onClick={() => effectPunch("reverb")}>Reverb +</button>
                <button type="button" onClick={() => effectPunch("delay")}>Delay +</button>
                <button type="button" onClick={() => effectPunch("echo")}>Echo +</button>
                <button type="button" onClick={() => effectPunch("bass")}>Bass +</button>
                <button type="button" onClick={() => effectPunch("ad")}>Ad Bed +</button>
                <button type="button" onClick={() => effectPunch("jingle")}>Jingle Bed +</button>
              </div>

              <div className="crossfader">
                <span>Deck A</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={crossfade}
                  onChange={(event) => setCrossfade(Number(event.target.value))}
                />
                <span>Deck B</span>
              </div>

              <div className="slider-bank">
                <ControlSlider label="Main" value={volume} setValue={setMainVolume} />
                <ControlSlider label="Mon" value={monitorVol} setValue={setMonitorVol} />
                <ControlSlider label="Mic" value={micGain} setValue={setMicGain} />
                <ControlSlider label="Music" value={musicGain} setValue={setMusicGain} />
                <ControlSlider label="Tempo" value={tempo} setValue={setTempo} />
                <ControlSlider label="Bass" value={bass} setValue={setBass} />
                <ControlSlider label="Mid" value={mid} setValue={setMid} />
                <ControlSlider label="High" value={high} setValue={setHigh} />
                <ControlSlider label="Rev" value={reverb} setValue={setReverb} />
                <ControlSlider label="Delay" value={delay} setValue={setDelay} />
                <ControlSlider label="Echo" value={echo} setValue={setEcho} />
                <ControlSlider label="Deck A" value={deckAGain} setValue={setDeckAGain} />
                <ControlSlider label="Deck B" value={deckBGain} setValue={setDeckBGain} />
                <ControlSlider label="Ads" value={adBed} setValue={setAdBed} />
                <ControlSlider label="Jing" value={jingleBed} setValue={setJingleBed} />
              </div>
            </section>

            <Turntable
              title="DECK B"
              label="AUTODJ / JINGLES"
              state={broadcast}
              quickPads={deckBQuickPads}
              onPad={firePad}
              onCue={cueBroadcast}
              onSync={studioSkip}
              onLoad={() => selectDisplay("ADS", "Deck B")}
            />
          </section>

          <section className="right-pads panel">
            <PanelHeading left="Studio Meter / Mode Display" right={selectedMode} />

            <div className="mode-display">
              <h3>{currentDjMode}</h3>
              <p>All-in-one smart switch controls AutoDJ, SmartDJ, and LiveDJ from the hero page.</p>

              <button type="button" onClick={() => firePad(visiblePads[0] || pads[0])}>
                Fire First {selectedMode}
              </button>
            </div>

            <div className="meter">
              <PanelHeading left="Studio Meter" right={isLive ? "Moving" : "Idle"} />

              <div className={isLive ? "meter-bars active" : "meter-bars"}>
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
              </div>
            </div>

            <div className="side-fill-buttons">
              <button type="button" onClick={() => callRadioAction("restart")}>Restart Backend</button>
              <button type="button" onClick={() => callRadioAction("start")}>Start Backend</button>
              <button type="button" onClick={() => callRadioAction("stop")}>Stop Backend</button>
              <button type="button" onClick={refreshNowPlaying}>Refresh Status</button>
            </div>
          </section>
        </section>

        <footer className="footer-dock panel">
          <PanelHeading
            left="Footer Control Dock"
            right="Blog • News • Weather • Store • Community • Chat • Upload"
          />
            <OwnerSmartDjCommand />
              <SmartDjControlPlaylist />


          <div className="footer-grid">
            {footerTools.map((tool) => (
              <a
                key={tool.label}
                href={tool.href}
                onClick={() => selectTool(tool)}
                className={`footer-tool ${tool.color}`}
              >
                <strong>{tool.label}</strong>
                <span>{tool.note}</span>
              </a>
            ))}
          </div>
        </footer>
      </section>

      <style jsx global>{`
        * { box-sizing: border-box; }
        body { margin: 0; }

        .control-page {
          min-height: 100vh;
          padding: 22px;
          color: #ffe9e9;
          background:
            radial-gradient(circle at top left, rgba(155, 0, 0, 0.35), transparent 28%),
            radial-gradient(circle at top right, rgba(95, 0, 0, 0.44), transparent 32%),
            linear-gradient(135deg, #000000 0%, #070000 38%, #160000 68%, #000000 100%);
          font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .shell {
          width: min(1850px, 100%);
          margin: 0 auto;
          padding: 22px;
          border-radius: 34px;
          background:
            linear-gradient(180deg, rgba(190, 0, 0, 0.12), transparent),
            rgba(0, 0, 0, 0.94);
          border: 1px solid rgba(185, 0, 0, 0.72);
          box-shadow:
            0 0 100px rgba(120, 0, 0, 0.44),
            inset 0 0 55px rgba(150, 0, 0, 0.12);
        }

        .topbar {
          display: flex;
          justify-content: space-between;
          gap: 22px;
          align-items: center;
          padding: 20px;
          border-radius: 28px;
          background:
            linear-gradient(90deg, rgba(120, 0, 0, 0.7), rgba(0, 0, 0, 0.9)),
            #030000;
          border: 1px solid rgba(190, 0, 0, 0.68);
        }

        .eyebrow {
          margin: 0 0 8px;
          color: #ff2b2b;
          font-size: 11px;
          font-weight: 950;
          letter-spacing: 0.25em;
        }

        h1 {
          margin: 0;
          color: #ffffff;
          font-size: clamp(34px, 5vw, 78px);
          line-height: 0.9;
          text-transform: uppercase;
          text-shadow: 0 0 16px rgba(255, 0, 0, 0.95), 0 0 40px rgba(120, 0, 0, 0.65);
        }

        .subtitle {
          margin: 12px 0 0;
          max-width: 980px;
          color: #ffc9c9;
          font-size: 15px;
          line-height: 1.5;
        }

        .brand-badge {
          min-width: 190px;
          min-height: 118px;
          display: grid;
          place-items: center;
          text-align: center;
          border-radius: 24px;
          background: radial-gradient(circle, rgba(190, 0, 0, 0.34), transparent 58%), #000;
          border: 1px solid rgba(255, 0, 0, 0.6);
          box-shadow: 0 0 34px rgba(160, 0, 0, 0.4);
        }

        .brand-badge .crown { color: #ff2b2b; font-size: 26px; line-height: 1; }
        .brand-badge strong { color: #ff1f1f; font-size: 40px; line-height: 1; text-shadow: 0 0 15px rgba(255, 0, 0, 0.9); }
        .brand-badge small { color: #ffd7d7; font-size: 11px; font-weight: 950; letter-spacing: 0.12em; }

        .status-row {
          display: grid;
          grid-template-columns: repeat(6, 1fr);
          gap: 12px;
          margin: 16px 0;
        }

        .status-card {
          position: relative;
          min-height: 88px;
          padding: 15px;
          border-radius: 21px;
          background: linear-gradient(145deg, rgba(170, 0, 0, 0.15), rgba(255, 255, 255, 0.018)), #030000;
          border: 1px solid rgba(180, 0, 0, 0.48);
          overflow: hidden;
        }

        .status-light {
          position: absolute;
          top: 15px;
          left: 15px;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: currentColor;
          box-shadow: 0 0 18px currentColor;
        }

        .status-light.green { color: #00ff76; }
        .status-light.red { color: #ff1b1b; }
        .status-light.yellow { color: #ff3b3b; }
        .status-light.orange { color: #ff4f00; }

        .status-card small {
          display: block;
          margin-left: 26px;
          color: #ff6b6b;
          font-size: 10px;
          font-weight: 950;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }

        .status-card strong {
          display: block;
          margin-top: 13px;
          color: #fff;
          font-size: 18px;
          text-transform: uppercase;
        }

        .panel,
        .central-log {
          border-radius: 26px;
          background: linear-gradient(145deg, rgba(140, 0, 0, 0.18), rgba(0, 0, 0, 0.8)), #030000;
          border: 1px solid rgba(180, 0, 0, 0.48);
          box-shadow: inset 0 0 30px rgba(255, 0, 0, 0.06);
          overflow: hidden;
        }

        .panel-heading {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding: 13px 15px;
          border-bottom: 1px solid rgba(180, 0, 0, 0.42);
        }

        .panel-heading span {
          color: #ff3b3b;
          font-size: 11px;
          font-weight: 950;
          letter-spacing: 0.16em;
          text-transform: uppercase;
        }

        .panel-heading b {
          color: #fff;
          font-size: 10px;
          text-transform: uppercase;
          text-align: right;
        }

        .central-log { margin-bottom: 16px; }

        .log-row {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          padding: 12px;
        }

        .log-card {
          display: grid;
          grid-template-columns: 54px 1fr;
          gap: 8px;
          align-items: center;
          min-height: 48px;
          padding: 8px;
          border-radius: 14px;
          background: rgba(255, 0, 0, 0.055);
          border: 1px solid rgba(180, 0, 0, 0.26);
        }

        .log-card span { color: #ff3b3b; font-size: 11px; font-weight: 950; }
        .log-card p { margin: 0; color: #ffd7d7; font-size: 12px; line-height: 1.3; }

        .now-playing-bar {
          display: grid;
          grid-template-columns: 1.3fr 0.7fr 0.9fr 220px;
          gap: 12px;
          align-items: center;
          margin-bottom: 16px;
          padding: 14px;
          border-radius: 24px;
          background: linear-gradient(90deg, rgba(180, 0, 0, 0.42), rgba(0, 0, 0, 0.92)), #030000;
          border: 1px solid rgba(190, 0, 0, 0.6);
          box-shadow: 0 0 38px rgba(160, 0, 0, 0.22);
        }

        .now-playing-bar div {
          min-height: 58px;
          display: grid;
          align-content: center;
          padding: 10px 14px;
          border-radius: 18px;
          background: rgba(0, 0, 0, 0.46);
          border: 1px solid rgba(180, 0, 0, 0.28);
        }

        .now-playing-bar span {
          color: #ff4b4b;
          font-size: 10px;
          font-weight: 950;
          letter-spacing: 0.18em;
          text-transform: uppercase;
        }

        .now-playing-bar strong {
          margin-top: 4px;
          color: #fff;
          font-size: 15px;
          text-transform: uppercase;
        }

        .now-playing-bar button {
          min-height: 58px;
          border: 0;
          border-radius: 18px;
          color: #fff;
          background: linear-gradient(180deg, #d90000, #580000);
          font-weight: 950;
          text-transform: uppercase;
          cursor: pointer;
          box-shadow: 0 6px 0 #050000;
        }

        .main-studio {
          display: grid;
          grid-template-columns: 0.98fr 2.28fr 0.9fr;
          gap: 16px;
          align-items: start;
        }

        .screen {
          min-height: 245px;
          padding: 24px 18px;
          background: repeating-linear-gradient(0deg, rgba(255, 0, 0, 0.04), rgba(255, 0, 0, 0.04) 1px, transparent 1px, transparent 8px);
        }

        .screen-kicker {
          margin: 0 0 12px;
          color: #ff3434;
          font-size: 11px;
          font-weight: 950;
          letter-spacing: 0.18em;
        }

        .screen h2 {
          margin: 0;
          color: #fff;
          font-size: clamp(24px, 2.6vw, 43px);
          line-height: 1;
          text-transform: uppercase;
        }

        .screen p { color: #ffd7d7; font-size: 15px; line-height: 1.5; }

        .lamp-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
          margin-top: 18px;
        }

        .lamp {
          display: grid;
          place-items: center;
          min-height: 37px;
          border-radius: 999px;
          color: #777;
          background: #080808;
          border: 1px solid rgba(255, 255, 255, 0.08);
          font-size: 10px;
          font-weight: 950;
        }

        .lamp.on.orange { background: #ff4f00; color: #fff; box-shadow: 0 0 15px rgba(255, 79, 0, 0.55); }
        .lamp.on.green { background: #00ff76; color: #00170b; box-shadow: 0 0 15px rgba(0, 255, 118, 0.55); }
        .lamp.on.red { background: #a40000; color: #fff; box-shadow: 0 0 15px rgba(255, 0, 0, 0.55); }
        .lamp.on.yellow { background: #ff1b1b; color: #fff; box-shadow: 0 0 15px rgba(255, 27, 27, 0.55); }

        .hero-smart-area { border-top: 1px solid rgba(180, 0, 0, 0.4); }

        .smart-mode-switch {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
          padding: 12px 12px 0;
        }

        .smart-mode-switch button {
          min-height: 62px;
          border: 0;
          border-radius: 16px;
          background: linear-gradient(180deg, #111, #000);
          color: #ff7a7a;
          border: 1px solid rgba(180, 0, 0, 0.4);
          cursor: pointer;
          text-transform: uppercase;
          font-weight: 950;
          box-shadow: 0 5px 0 rgba(0, 0, 0, 0.45);
        }

        .smart-mode-switch button span { display: block; font-size: 13px; }
        .smart-mode-switch button b { display: block; margin-top: 4px; font-size: 10px; color: #ffd7d7; }

        .smart-mode-switch button.active.auto {
          background: linear-gradient(180deg, #ff4f00, #5b1700);
          color: #fff;
          box-shadow: 0 0 22px rgba(255, 79, 0, 0.35), 0 5px 0 #050000;
        }

        .smart-mode-switch button.active.smart {
          background: linear-gradient(180deg, #ff1b1b, #5b0000);
          color: #fff;
          box-shadow: 0 0 22px rgba(255, 0, 0, 0.42), 0 5px 0 #050000;
        }

        .smart-mode-switch button.active.live {
          background: linear-gradient(180deg, #00ff76, #004b23);
          color: #00170b;
          box-shadow: 0 0 22px rgba(0, 255, 118, 0.32), 0 5px 0 #050000;
        }

        .display-switches,
        .center-pad-bank,
        .effect-buttons,
        .side-fill-buttons {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
          padding: 10px;
          border-radius: 18px;
          background: rgba(255, 0, 0, 0.035);
          border: 1px solid rgba(180, 0, 0, 0.18);
        }

        .display-switches {
          padding: 12px 12px 0;
          border: 0;
          background: transparent;
        }

        .display-btn {
          min-height: 44px;
          border: 0;
          border-radius: 14px;
          cursor: pointer;
          font-weight: 950;
          text-transform: uppercase;
          box-shadow: 0 5px 0 rgba(0, 0, 0, 0.45);
        }

        .display-btn.blood { background: linear-gradient(180deg, #d90000, #580000); color: #fff; }
        .display-btn.dark { background: linear-gradient(180deg, #151515, #000); color: #ff3b3b; border: 1px solid rgba(190, 0, 0, 0.55); }

        .hero-tabs {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 7px;
          padding: 12px;
        }

        .hero-tabs button,
        .center-pad-bank button,
        .effect-buttons button,
        .side-fill-buttons button {
          min-height: 35px;
          border-radius: 12px;
          background: #090909;
          color: #ff4b4b;
          border: 1px solid rgba(180, 0, 0, 0.38);
          font-size: 10px;
          cursor: pointer;
          font-weight: 950;
          text-transform: uppercase;
        }

        .center-pad-bank button,
        .effect-buttons button {
          min-height: 38px;
          color: #fff;
          background: linear-gradient(180deg, #a40000, #330000);
        }

        .hero-tabs button.active {
          background: #a40000;
          color: #fff;
          box-shadow: 0 0 18px rgba(255, 0, 0, 0.25);
        }

        .hero-pad-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
          padding: 0 12px 12px;
          max-height: 350px;
          overflow: auto;
        }

        .turntable-stage {
          display: grid;
          grid-template-columns: 1fr 390px 1fr;
          gap: 14px;
          align-items: stretch;
          padding: 18px;
          border-radius: 34px;
          background: radial-gradient(circle at center, rgba(150, 0, 0, 0.28), transparent 55%), linear-gradient(160deg, #100000, #000 52%, #120000);
          border: 1px solid rgba(190, 0, 0, 0.58);
        }

        .deck {
          position: relative;
          min-height: 760px;
          padding: 18px;
          overflow: hidden;
          border-radius: 32px;
          background: radial-gradient(circle at 50% 42%, rgba(160, 0, 0, 0.24), transparent 55%), linear-gradient(145deg, #090909, #000);
          border: 1px solid rgba(180, 0, 0, 0.48);
          box-shadow: inset 0 0 30px rgba(255, 0, 0, 0.045), 0 18px 30px rgba(0, 0, 0, 0.45);
        }

        .deck-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; }
        .deck-head strong { color: #ff3b3b; font-size: 22px; }
        .deck-head span { padding: 7px 11px; border-radius: 999px; color: #fff; font-size: 11px; border: 1px solid rgba(180, 0, 0, 0.55); }

        .platter-wrap {
          position: relative;
          width: min(360px, 100%);
          aspect-ratio: 1 / 1;
          display: grid;
          place-items: center;
          margin: 34px auto 18px;
        }

        .platter {
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background:
            radial-gradient(circle, #ff1b1b 0 4%, #090909 5% 10%, #222 11% 12%, #050505 13% 22%, #202020 23% 24%, #050505 25% 35%, #232323 36% 37%, #050505 38% 48%, #202020 49% 50%, #050505 51% 62%, #242424 63% 64%, #050505 65%),
            repeating-radial-gradient(circle, rgba(255, 255, 255, 0.08) 0 1px, transparent 1px 7px),
            conic-gradient(from 40deg, rgba(255, 0, 0, 0.85), transparent, rgba(120, 0, 0, 0.75), transparent, rgba(255, 0, 0, 0.85));
          border: 14px solid #111;
          box-shadow: 0 0 0 4px rgba(180, 0, 0, 0.2), 0 18px 35px rgba(0, 0, 0, 0.65), inset 0 0 45px rgba(0, 0, 0, 0.9);
        }

        .record-label {
          position: absolute;
          width: 72px;
          height: 72px;
          border-radius: 50%;
          background: radial-gradient(circle, #fff, #ff1b1b 58%, #420000);
          display: grid;
          place-items: center;
          color: #160000;
          font-weight: 950;
          box-shadow: 0 0 20px rgba(255, 0, 0, 0.35);
        }

        .deck.live .platter,
        .deck.live .record-label { animation: spin 0.9s linear infinite; }

        .deck.cue .platter,
        .deck.cue .record-label { animation: spin 2.6s linear infinite; }

        .needle {
          position: absolute;
          top: 20%;
          right: -2%;
          width: 44%;
          height: 9px;
          border-radius: 999px;
          transform: rotate(27deg);
          transform-origin: right center;
          background: linear-gradient(90deg, #ff1b1b, #650000);
          box-shadow: 0 0 16px rgba(255, 0, 0, 0.45);
        }

        .needle::after {
          content: "";
          position: absolute;
          right: -16px;
          top: -17px;
          width: 42px;
          height: 42px;
          border-radius: 50%;
          background: #ff1b1b;
          box-shadow: 0 0 18px rgba(255, 0, 0, 0.55);
        }

        .deck-label { text-align: center; }
        .deck-label b { display: block; color: #fff; font-size: 19px; }
        .deck-label span { display: block; margin-top: 7px; color: #ff8f8f; font-size: 11px; font-weight: 950; letter-spacing: 0.15em; text-transform: uppercase; }

        .deck-wheel-sliders {
          display: grid;
          gap: 8px;
          margin: 15px 0 12px;
          padding: 12px;
          border-radius: 18px;
          background: rgba(255, 0, 0, 0.045);
          border: 1px solid rgba(180, 0, 0, 0.24);
        }

        .deck-wheel-slider {
          display: grid;
          grid-template-columns: 58px 1fr 36px;
          gap: 8px;
          align-items: center;
        }

        .deck-wheel-slider label { color: #ff6868; font-size: 10px; font-weight: 950; text-transform: uppercase; }
        .deck-wheel-slider input { width: 100%; accent-color: #ff1b1b; }
        .deck-wheel-slider span { color: #fff; font-size: 10px; font-weight: 950; text-align: right; }

        .deck-buttons,
        .deck-quick-pads {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
          margin-top: 12px;
        }

        .deck-quick-pads {
          grid-template-columns: repeat(2, 1fr);
        }

        button { font-family: inherit; }

        .deck-buttons button,
        .deck-quick-pads button,
        .btn,
        .mode-buttons button,
        .pad,
        .main-play,
        .footer-tool,
        .display-btn {
          cursor: pointer;
          font-weight: 950;
          text-transform: uppercase;
          transition: transform 0.2s ease, filter 0.2s ease, box-shadow 0.2s ease;
        }

        .deck-buttons button,
        .deck-quick-pads button {
          min-height: 42px;
          border: 0;
          border-radius: 14px;
          color: #fff;
          background: linear-gradient(180deg, #b00000, #3b0000);
          box-shadow: 0 6px 0 #050000;
          font-size: 11px;
        }

        .deck-quick-pads button {
          min-height: 44px;
          background: linear-gradient(180deg, #181818, #000);
          border: 1px solid rgba(190, 0, 0, 0.5);
          color: #ff5959;
        }

        .broadcast-center {
          min-height: 760px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          padding: 13px;
          border-radius: 28px;
          background: linear-gradient(180deg, rgba(120, 0, 0, 0.18), transparent), #020202;
          border: 1px solid rgba(180, 0, 0, 0.52);
        }

        .cam-box {
          border-radius: 20px;
          overflow: hidden;
          background: #020000;
          border: 1px solid rgba(180, 0, 0, 0.42);
        }

        .cam-view {
          min-height: 148px;
          display: grid;
          place-items: center;
          text-align: center;
          padding: 14px;
          background: radial-gradient(circle, rgba(180, 0, 0, 0.32), transparent 60%), linear-gradient(135deg, #151515, #000);
        }

        .cam-view p { margin: 6px 0 0; color: #ffd7d7; font-size: 13px; }

        .cam-bars,
        .meter-bars {
          display: flex;
          align-items: end;
          gap: 6px;
        }

        .cam-bars { height: 70px; }

        .cam-bars i {
          width: 11px;
          height: 26px;
          border-radius: 999px;
          background: linear-gradient(#ff5a5a, #6f0000);
        }

        .cam-bars.active i,
        .meter-bars.active i { animation: meter 0.7s infinite ease-in-out; }

        .main-play {
          min-height: 72px;
          border: 0;
          border-radius: 20px;
          color: #fff;
          background: linear-gradient(180deg, #b00000, #3a0000);
          box-shadow: 0 7px 0 #050000, 0 0 28px rgba(180, 0, 0, 0.3);
        }

        .main-play.active {
          background: linear-gradient(180deg, #ff1b1b, #650000);
          box-shadow: 0 7px 0 #050000, 0 0 35px rgba(255, 0, 0, 0.45);
        }

        .main-play span { display: block; font-size: 11px; letter-spacing: 0.16em; }
        .main-play b { display: block; margin-top: 3px; font-size: 25px; }

        .broadcast-buttons,
        .mode-buttons {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 7px;
        }

        .btn {
          min-height: 44px;
          border: 0;
          border-radius: 14px;
          font-size: 10px;
          box-shadow: 0 5px 0 rgba(0, 0, 0, 0.4);
        }

        .btn.blood { background: #9b0000; color: #fff; }

        .mode-buttons button {
          min-height: 36px;
          border-radius: 12px;
          background: #080808;
          color: #ff4b4b;
          border: 1px solid rgba(180, 0, 0, 0.38);
          font-size: 10px;
        }

        .crossfader {
          display: grid;
          grid-template-columns: 58px 1fr 58px;
          align-items: center;
          gap: 8px;
          padding: 11px;
          border-radius: 18px;
          background: #070000;
          border: 1px solid rgba(180, 0, 0, 0.36);
        }

        .crossfader span {
          color: #ff4b4b;
          font-size: 10px;
          font-weight: 950;
          text-transform: uppercase;
          text-align: center;
        }

        .crossfader input { width: 100%; accent-color: #ff1b1b; }

        .slider-bank {
          display: grid;
          grid-template-columns: repeat(15, minmax(34px, 1fr));
          gap: 5px;
          min-height: 200px;
          padding: 7px;
          overflow-x: auto;
          border-radius: 18px;
          background: rgba(255, 0, 0, 0.035);
          border: 1px solid rgba(180, 0, 0, 0.18);
        }

        .control-slider {
          display: grid;
          justify-items: center;
          gap: 5px;
          padding: 6px 3px;
          border-radius: 13px;
          background: rgba(0, 0, 0, 0.56);
          border: 1px solid rgba(180, 0, 0, 0.18);
        }

        .control-slider label {
          color: #ff4b4b;
          font-size: 8px;
          font-weight: 950;
          text-transform: uppercase;
          text-align: center;
        }

        .control-slider input {
          writing-mode: bt-lr;
          -webkit-appearance: slider-vertical;
          width: 25px;
          height: 122px;
          accent-color: #ff1b1b;
        }

        .control-slider strong { color: #fff; font-size: 9px; }

        .pad {
          min-height: 56px;
          border: 0;
          border-radius: 16px;
          box-shadow: 0 5px 0 rgba(0, 0, 0, 0.42);
        }

        .pad small { display: block; font-size: 8px; letter-spacing: 0.14em; }
        .pad strong { display: block; margin-top: 4px; font-size: 12px; }

        .yellow { background: #ff4b4b; color: #fff; }
        .red { background: #9b0000; color: #fff; }
        .green { background: #00ff76; color: #00170b; }
        .blue { background: #00d1ff; color: #001014; }
        .purple { background: #7d1fff; color: #fff; }
        .orange { background: #ff4f00; color: #fff; }

        .mode-display { padding: 18px; }
        .mode-display h3 { margin: 0; color: #ff3b3b; font-size: 34px; line-height: 1; }
        .mode-display p { color: #ffd7d7; line-height: 1.45; }

        .mode-display button {
          width: 100%;
          min-height: 46px;
          border: 0;
          border-radius: 14px;
          background: linear-gradient(180deg, #b00000, #3b0000);
          color: #fff;
          font-weight: 950;
          text-transform: uppercase;
          cursor: pointer;
        }

        .meter { border-top: 1px solid rgba(180, 0, 0, 0.35); }
        .meter-bars { height: 120px; padding: 14px; }

        .meter-bars i {
          flex: 1;
          min-width: 7px;
          height: 22%;
          border-radius: 999px 999px 0 0;
          background: linear-gradient(#ff1b1b, #570000);
          opacity: 0.35;
        }

        .meter-bars.active i { opacity: 1; }

        .side-fill-buttons {
          margin: 14px;
          grid-template-columns: 1fr;
        }

        .footer-dock { margin-top: 16px; }

        .footer-grid {
          display: grid;
          grid-template-columns: repeat(10, 1fr);
          gap: 9px;
          padding: 13px;
        }

        .footer-tool {
          min-height: 64px;
          border: 0;
          border-radius: 16px;
          display: grid;
          place-items: center;
          text-align: center;
          text-decoration: none;
          box-shadow: 0 5px 0 rgba(0, 0, 0, 0.45);
        }

        .footer-tool strong { display: block; font-size: 12px; }
        .footer-tool span { display: block; margin-top: 3px; font-size: 9px; line-height: 1.2; text-transform: none; opacity: 0.86; }

        button:hover,
        .footer-tool:hover {
          transform: translateY(-2px);
          filter: brightness(1.08);
        }

        /* BIGGER TEXT + REQUESTED STATUS COLORS */
        .control-page {
          font-size: 18px;
        }

        .subtitle {
          font-size: 18px;
          line-height: 1.65;
        }

        .status-card {
          min-height: 104px;
          padding: 18px;
        }

        .status-card small {
          font-size: 13px;
        }

        .status-card strong {
          font-size: 24px;
        }

        .status-light.yellow {
          color: #ffd000;
        }

        .status-light.blue {
          color: #00d1ff;
        }

        .status-light.purple {
          color: #a855ff;
        }

        .panel-heading span {
          font-size: 14px;
        }

        .panel-heading b {
          font-size: 13px;
        }

        .screen h2 {
          font-size: clamp(32px, 3.2vw, 52px);
        }

        .screen p {
          font-size: 19px;
        }

        .now-playing-bar span {
          font-size: 13px;
        }

        .now-playing-bar strong {
          font-size: 20px;
        }

        .now-playing-bar button {
          font-size: 14px;
        }

        .lamp {
          min-height: 48px;
          font-size: 14px;
        }

        .lamp.on.yellow {
          background: #ffd000;
          color: #170b00;
          box-shadow: 0 0 18px rgba(255, 208, 0, 0.65);
        }

        .lamp.on.blue {
          background: #00d1ff;
          color: #001014;
          box-shadow: 0 0 18px rgba(0, 209, 255, 0.65);
        }

        .lamp.on.green {
          background: #00ff76;
          color: #00170b;
          box-shadow: 0 0 18px rgba(0, 255, 118, 0.65);
        }

        .lamp.on.purple {
          background: #a855ff;
          color: #fff;
          box-shadow: 0 0 18px rgba(168, 85, 255, 0.65);
        }

        .smart-mode-switch button span {
          font-size: 17px;
        }

        .smart-mode-switch button b {
          font-size: 13px;
        }

        .hero-tabs button,
        .mode-buttons button,
        .center-pad-bank button,
        .effect-buttons button,
        .side-fill-buttons button {
          font-size: 13px;
        }

        .pad small {
          font-size: 11px;
        }

        .pad strong {
          font-size: 16px;
        }

        .deck-head strong {
          font-size: 28px;
        }

        .deck-head span {
          font-size: 14px;
        }

        .deck-label b {
          font-size: 24px;
        }

        .deck-label span {
          font-size: 13px;
        }

        .deck-buttons button,
        .deck-quick-pads button,
        .btn {
          font-size: 13px;
        }

        .control-slider label {
          font-size: 10px;
        }

        .control-slider strong {
          font-size: 11px;
        }

        .deck-wheel-slider label,
        .deck-wheel-slider span {
          font-size: 12px;
        }

        .mode-display h3 {
          font-size: 42px;
        }

        .mode-display p {
          font-size: 18px;
        }

        .footer-grid {
          grid-template-columns: repeat(11, minmax(110px, 1fr));
        }

        .footer-tool strong {
          font-size: 15px;
        }

        .footer-tool span {
          font-size: 12px;
        }
        .owner-smartdj-command-box {
          display: grid;
          grid-template-columns: 160px 1fr 145px 180px;
          gap: 10px;
          align-items: center;
          margin: 12px 0 14px;
          padding: 12px;
          border-radius: 18px;
          background: rgba(0, 209, 255, 0.08);
          border: 1px solid rgba(0, 209, 255, 0.35);
        }

        .owner-smartdj-command-box strong {
          color: #00d1ff;
          font-size: 13px;
          font-weight: 950;
          letter-spacing: 0.12em;
        }

        .owner-smartdj-command-box input {
          min-height: 42px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,.18);
          padding: 0 12px;
          font-weight: 900;
          color: #111;
        }

        .owner-smartdj-command-box button {
          min-height: 42px;
          border: 0;
          border-radius: 12px;
          background: linear-gradient(180deg, #00d1ff, #00677a);
          color: #001014;
          font-weight: 950;
          text-transform: uppercase;
          cursor: pointer;
        }

        .owner-smartdj-command-box button:nth-of-type(2) {
          background: linear-gradient(180deg, #ffcc00, #9c5b00);
          color: #120700;
        }

        .owner-smartdj-command-box span {
          grid-column: 1 / -1;
          color: #fff;
          font-size: 13px;
          font-weight: 850;
        }
        
.owner-control-smartdj-playlist {
  margin: 14px 0;
  padding: 14px;
  border: 1px solid rgba(0, 217, 255, 0.45);
  border-radius: 18px;
  background: rgba(0, 12, 18, 0.92);
  box-shadow: 0 0 18px rgba(0, 217, 255, 0.12);
  color: #fff;
}

.owner-control-smartdj-playlist-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 10px;
}

.owner-control-smartdj-playlist-head strong {
  display: block;
  color: #00d9ff;
  font-size: 14px;
  font-weight: 950;
  letter-spacing: 0.12em;
}

.owner-control-smartdj-playlist-head span {
  display: block;
  margin-top: 3px;
  color: #ffffff;
  font-size: 12px;
  font-weight: 800;
}

.owner-control-smartdj-playlist-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.owner-control-smartdj-playlist-actions button,
.owner-control-smartdj-playlist-row button {
  border: 0;
  border-radius: 12px;
  padding: 9px 14px;
  background: linear-gradient(180deg, #ffcc00, #b98500);
  color: #120700;
  font-weight: 950;
  cursor: pointer;
  text-transform: uppercase;
}

.owner-control-smartdj-playlist-list {
  display: grid;
  gap: 8px;
}

.owner-control-smartdj-playlist-row {
  display: grid;
  grid-template-columns: 1fr 430px;
  align-items: center;
  gap: 10px;
  border: 1px solid rgba(255, 0, 0, 0.45);
  border-radius: 14px;
  padding: 9px;
  background: rgba(24, 0, 0, 0.82);
}

.owner-control-smartdj-playlist-row.is-playing {
  border-color: #00ff73;
  box-shadow: 0 0 16px rgba(0, 255, 115, 0.35);
}

.owner-control-smartdj-playlist-info b {
  display: block;
  color: #fff;
  font-size: 13px;
  font-weight: 950;
}

.owner-control-smartdj-playlist-info small {
  display: block;
  margin-top: 3px;
  color: #9ff3ff;
  font-size: 11px;
  font-weight: 800;
}

.owner-control-smartdj-empty,
.owner-control-smartdj-player-status {
  margin: 8px 0 0;
  color: #fff;
  font-size: 12px;
  font-weight: 850;
}


.owner-control-smartdj-bleep-note {
  display: block;
  margin-top: 4px;
  color: #ff4d4d !important;
  font-size: 11px;
  font-weight: 950;
}

@keyframes spin {
          to { transform: rotate(360deg); }
        }

        @keyframes meter {
          0%, 100% { height: 24%; }
          50% { height: 96%; }
        }

        @media (max-width: 1500px) {
          .status-row { grid-template-columns: repeat(3, 1fr); }
          .now-playing-bar { grid-template-columns: 1fr 1fr; }
          .main-studio { grid-template-columns: 1fr; }
          .turntable-stage { grid-template-columns: 1fr; }
          .deck,
          .broadcast-center { min-height: auto; }
          .log-row { grid-template-columns: repeat(2, 1fr); }
          .footer-grid { grid-template-columns: repeat(5, 1fr); }
        }

        @media (max-width: 760px) {
          .control-page { padding: 12px; }
          .shell { padding: 12px; border-radius: 24px; }
          .topbar { flex-direction: column; align-items: stretch; }
          .brand-badge { width: 100%; }

          .status-row,
          .log-row,
          .now-playing-bar,
          .lamp-grid,
          .hero-pad-grid,
          .smart-mode-switch {
            grid-template-columns: 1fr;
          }

          .broadcast-buttons,
          .mode-buttons,
          .hero-tabs,
          .display-switches,
          .footer-grid,
          .center-pad-bank,
          .effect-buttons {
            grid-template-columns: repeat(2, 1fr);
          }

          .slider-bank {
            grid-template-columns: repeat(15, 42px);
          }
        }
      `}</style>
    </main>
  );
}

function StatusCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "green" | "red" | "yellow" | "orange" | "blue" | "purple";
}) {
  return (
    <div className="status-card">
      <span className={`status-light ${tone}`} />
      <small>{label}</small>
      <strong>{value}</strong>
    </div>
  );
}

function PanelHeading({ left, right }: { left: string; right: string }) {
  return (
    <div className="panel-heading">
      <span>{left}</span>
      <b>{right}</b>
    </div>
  );
}

function Turntable({
  title,
  label,
  state,
  quickPads,
  onPad,
  onCue,
  onSync,
  onLoad,
}: {
  title: string;
  label: string;
  state: BroadcastState;
  quickPads: Pad[];
  onPad: (pad: Pad) => void;
  onCue: () => void;
  onSync: () => void;
  onLoad: () => void;
}) {
  const deckClass =
    state === "live" ? "deck live" : state === "cue" ? "deck cue" : "deck";

  return (
    <div className={deckClass}>
      <div className="deck-head">
        <strong>{title}</strong>
        <span>{state === "live" ? "SPINNING" : state === "cue" ? "CUED" : "READY"}</span>
      </div>

      <div className="platter-wrap">
        <div className="platter" />
        <div className="record-label">TC</div>
        <div className="needle" />
      </div>

      <div className="deck-label">
        <b>{label}</b>
        <span>
          {state === "live"
            ? "turntable spinning live"
            : state === "cue"
              ? "slow cue spin"
              : "ready"}
        </span>
      </div>

      <div className="deck-wheel-sliders">
        <DeckWheelSlider label="Pitch" defaultValue={52} />
        <DeckWheelSlider label="Trim" defaultValue={62} />
        <DeckWheelSlider label="Brake" defaultValue={36} />
        <DeckWheelSlider label="Scratch" defaultValue={48} />
        <DeckWheelSlider label="Torque" defaultValue={66} />
        <DeckWheelSlider label="Level" defaultValue={72} />
      </div>

      <div className="deck-buttons">
        <button type="button" onClick={onCue}>Cue</button>
        <button type="button" onClick={onSync}>Sync</button>
        <button type="button" onClick={onLoad}>Load</button>
      </div>

      <div className="deck-quick-pads">
        {quickPads.map((pad) => (
          <button key={`${title}-${pad.label}`} type="button" onClick={() => onPad(pad)}>
            {pad.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function DeckWheelSlider({
  label,
  defaultValue,
}: {
  label: string;
  defaultValue: number;
}) {
  const sliderInstanceId = useId();
  const storageKey = `tha-core-deck-slider-${sliderInstanceId}-${label}-${defaultValue}`;
  const [value, setValue] = useState(defaultValue);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(storageKey);
      if (saved === null) return;

      const savedNumber = Number(saved);
      if (!Number.isNaN(savedNumber)) {
        setValue(savedNumber);
      }
    } catch {
      // ignore storage errors
    }
  }, [storageKey]);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, String(value));
    } catch {
      // ignore storage errors
    }
  }, [storageKey, value]);

  return (
    <div className="deck-wheel-slider">
      <label>{label}</label>
      <input
        type="range"
        min="0"
        max="100"
        value={value}
        onChange={(event) => setValue(Number(event.target.value))}
      />
      <span>{value}%</span>
    </div>
  );
}

function ControlSlider({
  label,
  value,
  setValue,
}: {
  label: string;
  value: number;
  setValue: (value: number) => void;
}) {
  const storageKey = `tha-core-owner-slider-${label}`;
  const [localValue, setLocalValue] = useState(value);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(storageKey);

      if (saved !== null) {
        const savedNumber = Number(saved);

        if (!Number.isNaN(savedNumber)) {
          setLocalValue(savedNumber);
          setValue(savedNumber);
        }
      }
    } catch {
      // ignore storage errors
    }

    setLoaded(true);
  }, [storageKey, setValue]);

  useEffect(() => {
    if (!loaded) return;

    setValue(localValue);

    try {
      window.localStorage.setItem(storageKey, String(localValue));
    } catch {
      // ignore storage errors
    }
  }, [loaded, localValue, setValue, storageKey]);

  return (
    <div className="control-slider">
      <label>{label}</label>
      <input
        type="range"
        min="0"
        max="100"
        value={localValue}
        onChange={(event) => {
          const nextValue = Number(event.target.value);
          setLocalValue(nextValue);
          setValue(nextValue);
        }}
      />
      <strong>{localValue}%</strong>
    </div>
  );
}






































