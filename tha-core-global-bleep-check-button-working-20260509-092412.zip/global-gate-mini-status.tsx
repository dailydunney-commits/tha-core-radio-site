﻿"use client";

import { useEffect, useState } from "react";

type GateStatus = {
  gateOnline: boolean;
  gateMessage: string;
  autoDjDecision: string;
  autoDjMessage: string;
  candidateCount: number;
  bleepCount: number;
  updatedAt: string;
};

export default function GlobalGateMiniStatus() {
  const [status, setStatus] = useState<GateStatus>({
    gateOnline: false,
    gateMessage: "Checking Global Audio Gate...",
    autoDjDecision: "CHECKING",
    autoDjMessage: "Checking AutoDJ gate...",
    candidateCount: 0,
    bleepCount: 0,
    updatedAt: "",
  });

  const [testResult, setTestResult] = useState("No gate test run yet.");
  const [testing, setTesting] = useState(false);

  async function loadStatus() {
    try {
      const [gateRes, autoDjRes, bleepRes] = await Promise.all([
        fetch("/api/radio/global-audio-gate", { cache: "no-store" }),
        fetch("/api/autodj/gated-next", { cache: "no-store" }),
        fetch("/api/radio/bleep-job", { cache: "no-store" }),
      ]);

      const gate = await gateRes.json().catch(() => null);
      const autoDj = await autoDjRes.json().catch(() => null);
      const bleep = await bleepRes.json().catch(() => null);

      setStatus({
        gateOnline: Boolean(gate?.ok),
        gateMessage: gate?.message || "Gate status unavailable.",
        autoDjDecision: autoDj?.lastDecision || "IDLE",
        autoDjMessage: autoDj?.message || "AutoDJ gate status unavailable.",
        candidateCount: Number(autoDj?.candidateCount ?? 0),
        bleepCount: Number(bleep?.count ?? 0),
        updatedAt: new Date().toLocaleTimeString(),
      });
    } catch {
      setStatus((current) => ({
        ...current,
        gateOnline: false,
        gateMessage: "Global Audio Gate check failed.",
        updatedAt: new Date().toLocaleTimeString(),
      }));
    }
  }

  async function runGateTest(kind: "safe" | "dirty") {
    setTesting(true);
    setTestResult(kind === "safe" ? "Testing approved clean audio..." : "Testing dirty audio hold...");

    try {
      const body =
        kind === "safe"
          ? {
              source: "CONTROL_PANEL",
              mode: "owner_panel_test",
              track: {
                id: "owner-safe-test",
                title: "Owner Safe Test",
                artist: "Tha Core",
                processedAudioUrl: "/audio/smartdj/test-bleeped-clean.mp3",
              },
            }
          : {
              source: "CONTROL_PANEL",
              mode: "owner_panel_test",
              track: {
                id: "owner-dirty-test",
                title: "Owner Dirty Explicit Test",
                artist: "Tha Core",
                reason: "dirty explicit uncensored test",
                audioUrl: "/audio/smartdj/test-bleeped-clean.mp3",
              },
            };

      const res = await fetch("/api/radio/global-audio-gate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify(body),
      });

      const data = await res.json().catch(() => null);

      if (data?.allowBroadcast) {
        setTestResult(`APPROVED ✅ ${data?.decision || "ALLOW"}`);
      } else {
        setTestResult(`HELD ⛔ ${data?.decision || "BLOCKED"}`);
      }
    } catch {
      setTestResult("Gate test failed.");
    } finally {
      setTesting(false);
      loadStatus();
    }
  }

  useEffect(() => {
    loadStatus();
    const timer = window.setInterval(loadStatus, 5000);
    return () => window.clearInterval(timer);
  }, []);

  const gateColor = status.gateOnline ? "#00ff73" : "#ff3030";
  const held =
    status.autoDjDecision.includes("HELD") ||
    status.autoDjDecision.includes("HOLD") ||
    status.autoDjDecision.includes("BLOCK");

  return (
    <section
      style={{
        margin: "14px 0",
        padding: "14px",
        borderRadius: "18px",
        border: "1px solid rgba(0, 255, 115, 0.55)",
        background: "rgba(0, 8, 10, 0.92)",
        boxShadow: "0 0 18px rgba(0, 255, 115, 0.16)",
        color: "#fff",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h3 style={{ margin: 0, color: "#00ff73", letterSpacing: "0.12em" }}>
            GLOBAL AUDIO GATE STATUS
          </h3>
          <p style={{ margin: "6px 0 0", color: gateColor, fontWeight: 900 }}>
            {status.gateOnline ? "ONLINE" : "OFFLINE"} • {status.gateMessage}
          </p>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button type="button" onClick={() => runGateTest("safe")} disabled={testing} style={buttonStyle}>
            TEST APPROVED
          </button>
          <button type="button" onClick={() => runGateTest("dirty")} disabled={testing} style={buttonStyle}>
            TEST HELD
          </button>
          <button type="button" onClick={loadStatus} disabled={testing} style={buttonStyle}>
            REFRESH GATE
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(140px, 1fr))", gap: 10, marginTop: 12 }}>
        <div><strong>AutoDJ Decision</strong><br /><span style={{ color: held ? "#ff4d4d" : "#00d9ff" }}>{status.autoDjDecision}</span></div>
        <div><strong>AutoDJ Candidates</strong><br />{status.candidateCount}</div>
        <div><strong>Bleep Jobs Waiting</strong><br />{status.bleepCount}</div>
        <div><strong>Updated</strong><br />{status.updatedAt || "..."}</div>
      </div>

      <p style={{ margin: "10px 0 0", color: "#00d9ff", fontSize: 12, fontWeight: 900 }}>
        Last Test: {testResult}
      </p>

      <p style={{ margin: "6px 0 0", color: "#ffeb66", fontSize: 12, fontWeight: 800 }}>
        Rule: dirty/raw/unverified audio must stay held until clean or processed/bleeped audio is ready.
      </p>
    </section>
  );
}

const buttonStyle = {
  border: 0,
  borderRadius: 12,
  padding: "10px 14px",
  background: "linear-gradient(180deg, #ffcc00, #b98500)",
  color: "#120700",
  fontWeight: 950,
  cursor: "pointer",
  textTransform: "uppercase" as const,
};
